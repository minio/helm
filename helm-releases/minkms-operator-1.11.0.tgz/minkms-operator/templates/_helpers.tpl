{{/* 
    aistor.namespace returns the namespace for AIStor resources.
*/}}
{{- define "aistor.namespace" -}}
{{ $.Values.namespaceOverride | default $.Release.Namespace| trunc 63 | trimSuffix "-" | quote }}
{{- end -}}

{{/* 
    aistor.resolveImage resolves the given name into a fully qualified image name.
    - name: the name of the image in $.images
    - root: the root object
    - val: the value of the image in the current object
*/}}
{{- define "aistor.resolveImage" -}}
{{- $img := "" -}}
{{- if .val.image -}}
  {{- $img = .val.image -}}
{{- else -}}
  {{- $imageDef := index .root.images .name -}}
  {{- if not $imageDef -}}
    {{ fail (printf "Image '%s' not found in images definition" .name) }}
  {{- else if kindIs "string" $imageDef }}
    {{- $img = $imageDef -}}
  {{- else if kindIs "map" $imageDef }}
    {{- if (not $imageDef.repository) }}
      {{ fail (printf "Image definition for '%s' must have a 'repository' field" .name) }}
    {{- end -}}
    {{- $repos := .root.repositories | default dict -}}
    {{- if not (hasKey $repos $imageDef.repository) -}}
      {{ fail (printf "Unknown repository '%s' for image '%s'" $imageDef.repository .name) }}
    {{- end -}}
    {{- $repo := index $repos $imageDef.repository -}}

    {{- if (not $imageDef.image) }}
      {{ fail (printf "Image definition for '%s' must have an 'image' field" .name) }}
    {{- end -}}
    {{- $defaultImage := printf "%s%s" ($repo.pathPrefix | default "") $imageDef.image -}}
    {{- if $repo.hostname }}
      {{- $defaultImage = printf "%s/%s" $repo.hostname $defaultImage -}}
    {{- end }}
    {{- $img = $defaultImage -}}
  {{- end }}
{{- end -}}
{{- if and $img .root.global .root.global.fipsMode -}}
  {{- if contains "@" $img -}}
    {{ fail (printf "global.fipsMode cannot append a .fips tag to digest-pinned image %q; use a tag-based reference or disable global.fipsMode" $img) }}
  {{- end -}}
  {{- if not (contains ":" ($img | splitList "/" | last)) -}}
    {{ fail (printf "global.fipsMode cannot append a .fips tag to untagged image %q; specify an explicit tag or disable global.fipsMode" $img) }}
  {{- end -}}
  {{- $img = printf "%s.fips" $img -}}
{{- end -}}
{{- $img -}}
{{- end -}}

{{/* 
    aistor.resolveImagePullPolicy resolves the given name into a pull policy.
    - name: the name of the image in $.images
    - root: the root object
    - val: the value of the pull policy in the current object
*/}}
{{- define "aistor.resolveImagePullPolicy" -}}
{{- $emptyObj := ("{}" | fromJson) -}}
{{- $images := .root.images | default $emptyObj -}}
{{- $imageDef := index $images .name -}}
{{- if kindIs "map" $imageDef }}
{{- $repositoryName := $imageDef.repository | default "" -}}
{{- $repo := index .root.repositories $repositoryName | default $emptyObj -}}
{{- .val.imagePullPolicy | default $repo.imagePullPolicy | default "" -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end -}}

{{/* 
    aistor.resolveImagePullSecrets resolves the given name into a pull secrets.
    - name: the name of the image in $.images
    - root: the root object
*/}}
{{- define "aistor.resolveImagePullSecrets" -}}
{{- $emptyObj := ("{}" | fromJson) -}}
{{- $emptyArray := ("[]" | fromJsonArray) -}}
{{- $images := .root.images | default $emptyObj -}}
{{- $imageDef := index $images .name -}}
{{- if kindIs "map" $imageDef }}
{{- $repositoryName := $imageDef.repository | default "" -}}
{{- $repo := index .root.repositories $repositoryName | default $emptyObj -}}
{{- $repo.imagePullSecrets | default $emptyArray | toJson -}}
{{- else -}}
{{- $emptyArray | toJson -}}
{{- end -}}
{{- end -}}

{{/* 
    aistor.resolveEnv resolves the given name into the environment.
    - name: the name of the image in $.images
    - root: the root object
*/}}
{{- define "aistor.resolveEnv" -}}
{{- $emptyObj := ("{}" | fromJson) -}}
{{- $emptyArray := ("[]" | fromJsonArray) -}}
{{- $images := .root.images | default $emptyObj -}}
{{- $imageDef := index $images .name | default $emptyObj -}}
{{- if kindIs "map" $imageDef }}
{{- $imageDef.env | default $emptyArray | toJson -}}
{{- else -}}
{{- $emptyArray | toJson -}}
{{- end -}}
{{- end -}}

{{/*
    aistor.isOpenShift returns whether the current cluster is OpenShift.
*/}}
{{- define "aistor.isOpenShift" -}}
{{- if ($.Values.global.forceOpenShift | default (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints")) -}}
{{- true -}}
{{- end -}}
{{- end -}}

{{/*
    aistor.containerSecurityContext renders the container security context. On
    OpenShift the SCC assigns the UID and GID, so runAsUser and runAsGroup are
    dropped while the remaining hardening fields are preserved.
    Expects a dict with "sc" (the security context) and "root" (the root context).
*/}}
{{- define "aistor.containerSecurityContext" -}}
{{- $sc := .sc -}}
{{- if include "aistor.isOpenShift" .root -}}
{{- $sc = omit $sc "runAsUser" "runAsGroup" -}}
{{- end -}}
{{- toYaml $sc -}}
{{- end -}}

{{/*
    aistor.operatorEnabled returns whether the operator is enabled.
*/}}
{{- define "aistor.operatorEnabled" -}}
{{- $emptyObj := "{}" | fromJson -}}
{{- $operators := .root.operators | default $emptyObj -}}
{{- $opValue := index $operators .operator | default $emptyObj }}
{{- if not $opValue.disabled }}
{{- true -}}
{{- end -}}
{{- end -}}

{{/*
    aistor.operators returns the default information for all operators
*/}}
{{- define "aistor.operators" -}}
minkms:
  images: ["minkms","minkms-sidecar"]
{{- end -}}

{{/*
    aistor.watchedNamespaces returns the list of watched namespaces for an operator.
    Per-operator value takes precedence over global.operator.watchedNamespaces.
    Returns an empty list when neither is set (cluster-wide mode).
    - operator: the operator name
    - root: the root values object
*/}}
{{- define "aistor.watchedNamespaces" -}}
{{- $emptyObj := "{}" | fromJson -}}
{{- $emptyArray := "[]" | fromJsonArray -}}
{{- $operators := .root.operators | default $emptyObj -}}
{{- $opValue := index $operators .operator | default $emptyObj -}}
{{- $globalOp := ((.root.global | default $emptyObj).operator) | default $emptyObj -}}
{{- if hasKey $opValue "watchedNamespaces" -}}
{{- $opValue.watchedNamespaces | toJson -}}
{{- else if hasKey $globalOp "watchedNamespaces" -}}
{{- $globalOp.watchedNamespaces | toJson -}}
{{- else -}}
{{- $emptyArray | toJson -}}
{{- end -}}
{{- end -}}

{{/*
    aistor.render renders a value that may itself contain template directives.
    This mirrors the helper already used by the aistor-operator, aistor-objectstore,
    aistor-aihub, aistor-prompt and minkms charts, so extraResources behaves
    identically here.
    Usage:
    {{ include "aistor.render" ( dict "value" .Values.path.to.the.Value "context" $) }}
*/}}
{{- define "aistor.render" -}}
  {{- if typeIs "string" .value }}
    {{- tpl .value .context }}
  {{- else }}
    {{- tpl (.value | toYaml) .context }}
  {{- end }}
{{- end -}}
