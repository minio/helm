{{/*
    directpv.isOpenShift returns whether the current cluster is OpenShift.
*/}}
{{- define "directpv.isOpenShift" -}}
{{- if ($.Values.forceOpenShift | default (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints")) -}}
{{- true -}}
{{- end -}}
{{- end -}}

{{/*
    directpv.isLegacy returns whether legacy volumes found.
    If Values.forceLegacyFlag is set, then it will use that value.
    If it is not set the template probes it from running cluster by
      - If any volume has 'directpv.min.io/migrated: true' label in directpvvolumes CRD or
        If at least one volume in directcsivolumes CRD

    PS: Note that auto-detect only works when Helm actually is able to
        read the resources from the cluster. It won't work during a dry-run
        or when using the `helm template` command.
*/}}
{{- define "directpv.isLegacy" -}}
{{- if hasKey .Values "forceLegacyFlag" -}}
  {{- $.Values.forceLegacyFlag -}}
{{- else -}}
  {{- $hasLegacyVolumes := false -}}
  {{- if (lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" "directcsivolumes.direct.csi.min.io") -}}
    {{- $legacyVolumes := lookup "direct.csi.min.io/v1beta5" "DirectCSIVolume" "" "" -}}
    {{- $hasLegacyVolumes = and $legacyVolumes (gt (len $legacyVolumes.items) 0) -}}
  {{- end -}}
  {{- $hasMigratedVolumes := false -}}
  {{- if (lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" "directpvvolumes.directpv.min.io") -}}
    {{- $volumes := lookup "directpv.min.io/v1beta1" "DirectPVVolume" "" "" -}}
    {{- if and $volumes (hasKey $volumes "items") -}}
      {{- range $volume := $volumes.items -}}
        {{- $labels := $volume.metadata.labels -}}
        {{- if and $labels (eq (get $labels "directpv.min.io/migrated") "true") -}}
          {{- $hasMigratedVolumes = true -}}
          {{- break -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
  {{- or $hasLegacyVolumes $hasMigratedVolumes -}}
{{- end -}}
{{- end -}}

{{/*
    directpv.defaultImages defines the default images used by DirectPV.
*/}}
{{- define "directpv.defaultImages" -}}
{{- if ($.Values.forceOpenShift | default (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints")) -}}
{{/* images when running on OpenShift */}}
directpv: quay.io/minio/directpv@sha256:20105107c1e381736e843f37332c138365dfe1588b0fecb03df106c89a5aa0ab
livenessprobe: registry.redhat.io/openshift4/ose-csi-livenessprobe-rhel8@sha256:9309cf88631e1cbb5362081a65f2de752cc130d231e8ba2bdd9ef640b51a6b66
csiNodeDriverRegistrar: registry.redhat.io/openshift4/ose-csi-node-driver-registrar-rhel8@sha256:9006d4a80df02b51102961e70e55ae08e2757fc4c62d3c2605b8ffed3a344e8d
csiProvisioner: registry.redhat.io/openshift4/ose-csi-external-provisioner-rhel8@sha256:ffc107c70d24eb86d2120d4bce217bcfebb46694817217f134ead9e9b72d2ff3
csiResizer: registry.redhat.io/openshift4/ose-csi-external-resizer-rhel8@sha256:ed845b49de7e1c363bc8e8485a04288c03125a3cff7c7f100d35b5b88645725a
{{- else -}}
{{/* images when running on vanilla Kubernetes */}}
directpv: quay.io/minio/directpv:v5.0.2
livenessprobe: quay.io/minio/livenessprobe:v2.15.0-0
csiNodeDriverRegistrar: quay.io/minio/csi-node-driver-registrar:v2.13.0-0
csiProvisioner: quay.io/minio/csi-provisioner:v5.2.0-0
csiResizer: quay.io/minio/csi-resizer:v1.13.1-0
{{- end -}}
{{- end -}}

{{/*
    directpv.resolveImage returns the proper image for the given name.
*/}}
{{- define "directpv.resolveImage" -}}
{{- $emptyObj := ("{}" | fromJson) -}}
{{- $defaultImages := (include "directpv.defaultImages" .root | fromYaml) -}}
{{- $defaultImage := index $defaultImages .name -}}
{{- $images := .root.Values.images | default $emptyObj -}}
{{- $image := index $images .name -}}
{{- $image | default $defaultImage | default $defaultImages -}}
{{- end -}}

{{/*
    directpv.kubeletDirPath defines the default kubelet directory path.
*/}}
{{- define "directpv.kubeletDirPath" -}}
{{- clean (trimSuffix "/" (default "/var/lib/kubelet" .Values.kubeletDirPath)) -}}
{{- end -}}
