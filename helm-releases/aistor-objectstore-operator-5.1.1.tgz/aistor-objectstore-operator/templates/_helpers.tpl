{{/* 
    aistor.namespace returns the namespace for AIStor resources.
*/}}
{{- define "aistor.namespace" -}}
{{ $.Values.namespaceOverride | default $.Release.Namespace| trunc 63 | trimSuffix "-" | quote }}
{{- end -}}

{{/* 
    aistor.resolveImage resolves the given name into a fully qualified image name.
    - name: the name of the image in $.images
    - root: the root object
    - val: the value of the image in the current object
*/}}
{{- define "aistor.resolveImage" -}}

{{- $emptyObj := ("{}" | fromJson) -}}

{{- $defaultImages := (include "aistor.defaultImages" . | fromYaml) -}}
{{- $defaultImageDef := index $defaultImages .name -}}

{{- $images := .root.images | default $emptyObj -}}
{{- $imageDef := index $images .name -}}

{{- $repositoryName := "" -}}
{{- $image := "" -}}

{{- if kindIs "map" $imageDef }}
  {{- $repositoryName = $imageDef.repository | default "" -}}
  {{- $image = $imageDef.image | default "" -}}
{{- else if kindIs "string" $imageDef }}
  {{- $image = $imageDef -}}  # Assume it's the full image string (e.g. quay.io/foo/bar:tag)
{{- end }}

{{- if eq $repositoryName "" }}
  {{- if kindIs "map" $defaultImageDef }}
    {{- $repositoryName = $defaultImageDef.repository | default "" -}}
    {{- if eq $image "" }}
      {{- $image = $defaultImageDef.image | default "" -}}
    {{- end }}
  {{- else if kindIs "string" $defaultImageDef }}
    {{- $image = $defaultImageDef -}}
  {{- end }}
{{- end }}

{{- if and (ne $image "") (eq $repositoryName "") }}
  {{- /* Image is full path like quay.io/repo/image:tag, just use it */ -}}
  {{- $image -}}
{{- else }}
  {{- $defaultRepositories := (include "aistor.defaultRepositories" . | fromYaml) -}}
  {{- $defaultRepoDef := index $defaultRepositories $repositoryName -}}
  {{- $defaultRepo := $defaultRepoDef | default "" -}}

  {{- $repoDef := index .root.repositories $repositoryName -}}
  {{- $repo := $repoDef | default $defaultRepo | default $emptyObj -}}

  {{- $defaultImage := printf "%s%s" ($repo.pathPrefix | default "") $image -}}
  {{- if $repo.hostname }}
    {{- $defaultImage = printf "%s/%s%s" $repo.hostname ($repo.pathPrefix | default "") $image -}}
  {{- end }}

  {{- .val.image | default $defaultImage -}}
{{- end }}

{{- end -}}

{{/* 
    aistor.resolveImagePullPolicy resolves the given name into a pull policy.
    - name: the name of the image in $.images
    - root: the root object
    - val: the value of the pull policy in the current object
*/}}
{{- define "aistor.resolveImagePullPolicy" -}}

{{- $emptyObj := ("{}" | fromJson) -}}

{{- $defaultImages := (include "aistor.defaultImages" . | fromYaml) -}}
{{- $defaultImageDef := index $defaultImages .name -}}

{{- $images := .root.images | default $emptyObj -}}
{{- $imageDef := index $images .name -}}

{{- $repositoryName := $imageDef.repository | default $defaultImageDef.repository | default "" -}}

{{- $defaultRepositories := (include "aistor.defaultRepositories" . | fromYaml) -}}
{{- $defaultRepoDef := index $defaultRepositories $repositoryName -}}
{{- $defaultRepo := $defaultRepoDef | default "" -}}

{{- $repoDef := index .root.repositories $repositoryName -}}
{{- $repo := $repoDef | default $defaultRepo | default $emptyObj -}}

{{- .val.imagePullPolicy | default $repo.imagePullPolicy | default "" -}}
{{- end -}}

{{/* 
    aistor.resolveImagePullSecrets resolves the given name into a pull secrets.
    - name: the name of the image in $.images
    - root: the root object
*/}}
{{- define "aistor.resolveImagePullSecrets" -}}

{{- $emptyObj := ("{}" | fromJson) -}}
{{- $emptyArray := ("[]" | fromJsonArray) -}}

{{- $defaultImages := (include "aistor.defaultImages" . | fromYaml) -}}
{{- $defaultImageDef := index $defaultImages .name -}}

{{- $images := .root.images | default $emptyObj -}}
{{- $imageDef := index $images .name -}}

{{- $repositoryName := $imageDef.repository | default $defaultImageDef.repository | default "" -}}

{{- $defaultRepositories := (include "aistor.defaultRepositories" . | fromYaml) -}}
{{- $defaultRepoDef := index $defaultRepositories $repositoryName -}}
{{- $defaultRepo := $defaultRepoDef | default "" -}}

{{- $repoDef := index .root.repositories $repositoryName -}}
{{- $repo := $repoDef | default $defaultRepo | default $emptyObj -}}

{{- $repo.imagePullSecrets | default $emptyArray | toJson -}}
{{- end -}}

{{/* 
    aistor.resolveEnv resolves the given name into the environment.
    - name: the name of the image in $.images
    - root: the root object
*/}}
{{- define "aistor.resolveEnv" -}}

{{- $emptyObj := ("{}" | fromJson) -}}
{{- $emptyArray := ("[]" | fromJsonArray) -}}

{{- $defaultImages := (include "aistor.defaultImages" . | fromYaml) -}}
{{- $defaultImageDef := index $defaultImages .name -}}

{{- $images := .root.images | default $emptyObj -}}
{{- $imageDef := index $images .name -}}

{{- $imageDef.env | default $defaultImageDef.env | default $emptyArray | toJson -}}

{{- end -}}

{{/*
    aistor.isOpenShift returns whether the current cluster is OpenShift.
*/}}
{{- define "aistor.isOpenShift" -}}
{{- if ($.Values.global.forceOpenShift | default (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints")) -}}
{{- true -}}
{{- end -}}
{{- end -}}

{{/*
    aistor.operatorSTSEnabled returns whether the old STS implementation
    is still enabled.
*/}}
{{- define "aistor.operatorSTSEnabled" -}}
{{- $emptyObj := ("{}" | fromJson) -}}
{{- if (default (get $.Values.operators "object-store") $emptyObj).enableSTS -}}
{{- true -}}
{{- end -}}
{{- end -}}

{{/*
    aistor.operatorEnabled returns whether the operator is enabled.
*/}}
{{- define "aistor.operatorEnabled" -}}
{{- $emptyObj := "{}" | fromJson -}}
{{- $operators := .root.operators | default $emptyObj -}}
{{- $opValue := index $operators .operator | default $emptyObj }}
{{- if not $opValue.disabled }}
{{- true -}}
{{- end -}}
{{- end -}}

{{/*
    aistor.defaultRepositories returns the default repositories
*/}}
{{- define "aistor.defaultRepositories" -}}
aistor:
  hostname: quay.io
  pathPrefix: minio/aistor/
minio:
  hostname: quay.io
  pathPrefix: minio/
{{- end -}}

{{/*
    aistor.operators returns the default information for all operators
*/}}
{{- define "aistor.operators" -}}
adminjob:
  images: ["mc"]
aihub:
  images: ["aihub"]
object-store:
  images: ["kes","kes-sidecar","minio","minio-sidecar"]
  extraEnv:
  - name: OPERATOR_STS_ENABLED
    {{- $emptyObj := ("{}" | fromJson) -}}
    {{- if (include "aistor.operatorSTSEnabled" .) }}
    value: "on"
    {{- else }}
    value: "off"
    {{- end }}
prompt:
  images: ["prompt"]
warp:
  images: ["warp"]
{{- end -}}

{{/* IMPORTANT: EVERYTHING BELOW THIS LINE WILL IS AUTOGENERATED */}}
{{/* AUTOGENERATE */}}

{{/*
    aistor.defaultImages returns the default list of images.
*/}}
{{- define "aistor.defaultImages" -}}
aihub:
  repository: aistor
  image: aihub:RELEASE.2024-12-13T23-00-47Z
firewall:
  repository: aistor
  image: minwall:RELEASE.2024-11-01T19-53-30Z
kes:
  repository: aistor
  image: kes:RELEASE.2025-07-15T11-40-19Z
kes-sidecar:
  repository: aistor
  image: kes-sidecar:RELEASE.2025-07-01T00-09-56Z
mc:
  repository: aistor
  image: mc:RELEASE.2025-08-06T14-45-28Z
minio:
  repository: aistor
  image: minio:RELEASE.2025-08-13T17-08-54Z
minio-sidecar:
  repository: aistor
  image: minio-sidecar:RELEASE.2025-06-30T21-59-04Z
operator:
  repository: aistor
  image: operator:RELEASE.2025-08-19T17-53-00Z
prompt:
  repository: aistor
  image: prompt:RELEASE.2025-01-17T21-55-43Z
warp:
  repository: minio
  image: warp:v1.3.0
{{- end -}}
