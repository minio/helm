{{/* vim: set filetype=mustache: */}}
{{/*
    minkmsEnclave.name returns the enclave resource name, defaulting to the release name.
*/}}
{{- define "minkmsEnclave.name" -}}
{{- .Values.enclave.name | default .Release.Name -}}
{{- end -}}

{{/*
    minkmsEnclave.namespace returns the namespace for all resources.
*/}}
{{- define "minkmsEnclave.namespace" -}}
{{- .Values.namespaceOverride | default .Release.Namespace -}}
{{- end -}}
