{{/* 
    aistor.namespace returns the namespace for AIStor resources.
*/}}
{{- define "aistor.namespace" -}}
{{ $.Values.namespaceOverride | default $.Release.Namespace| trunc 63 | trimSuffix "-" | quote }}
{{- end -}}

{{/* 
    aistor.resolveImage resolves the given name into a fully qualified image name.
    - name: the name of the image in $.images
    - root: the root object
    - val: the value of the image in the current object
*/}}
{{- define "aistor.resolveImage" -}}

{{- $emptyObj := ("{}" | fromJson) -}}

{{- $defaultImages := (include "aistor.defaultImages" . | fromYaml) -}}
{{- $defaultImageDef := index $defaultImages .name -}}

{{- $images := .root.images | default $emptyObj -}}
{{- $imageDef := index $images .name -}}

{{- $repositoryName := "" -}}
{{- $image := "" -}}

{{- if kindIs "map" $imageDef }}
  {{- $repositoryName = $imageDef.repository | default "" -}}
  {{- $image = $imageDef.image | default "" -}}
{{- else if kindIs "string" $imageDef }}
  {{- $image = $imageDef -}}  # Assume it's the full image string (e.g. quay.io/foo/bar:tag)
{{- end }}

{{- if eq $repositoryName "" }}
  {{- if kindIs "map" $defaultImageDef }}
    {{- $repositoryName = $defaultImageDef.repository | default "" -}}
    {{- if eq $image "" }}
      {{- $image = $defaultImageDef.image | default "" -}}
    {{- end }}
  {{- else if kindIs "string" $defaultImageDef }}
    {{- $image = $defaultImageDef -}}
  {{- end }}
{{- end }}

{{- if and (ne $image "") (eq $repositoryName "") }}
  {{- /* Image is full path like quay.io/repo/image:tag, just use it */ -}}
  {{- $image -}}
{{- else }}
  {{- $defaultRepositories := (include "aistor.defaultRepositories" . | fromYaml) -}}
  {{- $defaultRepoDef := index $defaultRepositories $repositoryName -}}
  {{- $defaultRepo := $defaultRepoDef | default "" -}}

  {{- $repoDef := index .root.repositories $repositoryName -}}
  {{- $repo := $repoDef | default $defaultRepo | default $emptyObj -}}

  {{- $defaultImage := printf "%s%s" ($repo.pathPrefix | default "") $image -}}
  {{- if $repo.hostname }}
    {{- $defaultImage = printf "%s/%s%s" $repo.hostname ($repo.pathPrefix | default "") $image -}}
  {{- end }}

  {{- .val.image | default $defaultImage -}}
{{- end }}

{{- end -}}

{{/* 
    aistor.resolveImagePullPolicy resolves the given name into a pull policy.
    - name: the name of the image in $.images
    - root: the root object
    - val: the value of the pull policy in the current object
*/}}
{{- define "aistor.resolveImagePullPolicy" -}}

{{- $emptyObj := ("{}" | fromJson) -}}

{{- $defaultImages := (include "aistor.defaultImages" . | fromYaml) -}}
{{- $defaultImageDef := index $defaultImages .name -}}

{{- $images := .root.images | default $emptyObj -}}
{{- $imageDef := index $images .name -}}

{{- $repositoryName := $imageDef.repository | default $defaultImageDef.repository | default "" -}}

{{- $defaultRepositories := (include "aistor.defaultRepositories" . | fromYaml) -}}
{{- $defaultRepoDef := index $defaultRepositories $repositoryName -}}
{{- $defaultRepo := $defaultRepoDef | default "" -}}

{{- $repoDef := index .root.repositories $repositoryName -}}
{{- $repo := $repoDef | default $defaultRepo | default $emptyObj -}}

{{- .val.imagePullPolicy | default $repo.imagePullPolicy | default "" -}}
{{- end -}}

{{/* 
    aistor.resolveImagePullSecrets resolves the given name into a pull secrets.
    - name: the name of the image in $.images
    - root: the root object
*/}}
{{- define "aistor.resolveImagePullSecrets" -}}

{{- $emptyObj := ("{}" | fromJson) -}}
{{- $emptyArray := ("[]" | fromJsonArray) -}}

{{- $defaultImages := (include "aistor.defaultImages" . | fromYaml) -}}
{{- $defaultImageDef := index $defaultImages .name -}}

{{- $images := .root.images | default $emptyObj -}}
{{- $imageDef := index $images .name -}}

{{- $repositoryName := $imageDef.repository | default $defaultImageDef.repository | default "" -}}

{{- $defaultRepositories := (include "aistor.defaultRepositories" . | fromYaml) -}}
{{- $defaultRepoDef := index $defaultRepositories $repositoryName -}}
{{- $defaultRepo := $defaultRepoDef | default "" -}}

{{- $repoDef := index .root.repositories $repositoryName -}}
{{- $repo := $repoDef | default $defaultRepo | default $emptyObj -}}

{{- $repo.imagePullSecrets | default $emptyArray | toJson -}}
{{- end -}}

{{/* 
    aistor.resolveEnv resolves the given name into the environment.
    - name: the name of the image in $.images
    - root: the root object
*/}}
{{- define "aistor.resolveEnv" -}}

{{- $emptyObj := ("{}" | fromJson) -}}
{{- $emptyArray := ("[]" | fromJsonArray) -}}

{{- $defaultImages := (include "aistor.defaultImages" . | fromYaml) -}}
{{- $defaultImageDef := index $defaultImages .name -}}

{{- $images := .root.images | default $emptyObj -}}
{{- $imageDef := index $images .name -}}

{{- $imageDef.env | default $defaultImageDef.env | default $emptyArray | toJson -}}

{{- end -}}

{{/*
    aistor.isOpenShift returns whether the current cluster is OpenShift.
*/}}
{{- define "aistor.isOpenShift" -}}
{{- if ($.Values.global.forceOpenShift | default (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints")) -}}
{{- true -}}
{{- end -}}
{{- end -}}


{{/*
    aistor.operatorEnabled returns whether the operator is enabled.
*/}}
{{- define "aistor.operatorEnabled" -}}
{{- $emptyObj := "{}" | fromJson -}}
{{- $operators := .root.operators | default $emptyObj -}}
{{- $opValue := index $operators .operator | default $emptyObj }}
{{- if not $opValue.disabled }}
{{- true -}}
{{- end -}}
{{- end -}}

{{/*
    aistor.webhookEnabled returns whether the object-store webhook is enabled.
    Webhook is enabled when:
    - object-store operator is not disabled AND
    - webhook is not explicitly set to false (boolean) AND
    - webhook.enabled is not false
*/}}
{{- define "aistor.webhookEnabled" -}}
{{- $emptyObj := "{}" | fromJson -}}
{{- $operators := .Values.operators | default $emptyObj -}}
{{- $objectStore := index $operators "object-store" | default $emptyObj -}}
{{- $webhookRaw := index $objectStore "webhook" -}}
{{- $webhook := $webhookRaw | default $emptyObj -}}
{{- $webhookExplicitlyFalse := and (kindIs "bool" $webhookRaw) (not $webhookRaw) -}}
{{- if and (not $objectStore.disabled) (not (or $webhookExplicitlyFalse (eq $webhook.enabled false))) -}}
{{- true -}}
{{- end -}}
{{- end -}}

{{/*
    aistor.defaultRepositories returns the default repositories
*/}}
{{- define "aistor.defaultRepositories" -}}
aistor:
  hostname: quay.io
  pathPrefix: minio/aistor/
{{- end -}}

{{/*
    aistor.operators returns the default information for all operators
*/}}
{{- define "aistor.operators" -}}
adminjob:
  images: ["mc"]
aihub:
  images: ["aihub"]
object-store:
  images: ["kes","kes-sidecar","minio","minio-sidecar"]
prompt:
  images: ["prompt"]
warp:
  images: ["warp"]
{{- end -}}

{{/* IMPORTANT: EVERYTHING BELOW THIS LINE WILL IS AUTOGENERATED */}}
{{/* AUTOGENERATE */}}

{{/*
    aistor.defaultImages returns the default list of images.
*/}}
{{- define "aistor.defaultImages" -}}
aihub:
  repository: aistor
  image: aihub:RELEASE.2025-12-11T18-08-15Z
firewall:
  repository: aistor
  image: minwall:RELEASE.2024-11-01T19-53-30Z
kes:
  repository: aistor
  image: kes:RELEASE.2025-12-30T19-30-40Z
kes-sidecar:
  repository: aistor
  image: kes-sidecar:RELEASE.2026-02-09T03-08-34Z
mc:
  repository: aistor
  image: mc:RELEASE.2026-02-07T19-37-38Z
minio:
  repository: aistor
  image: minio:RELEASE.2026-02-07T07-43-34Z
minio-sidecar:
  repository: aistor
  image: minio-sidecar:RELEASE.2026-02-09T03-10-35Z
operator:
  repository: aistor
  image: operator:RELEASE.2026-02-09T03-12-43Z
prompt:
  repository: aistor
  image: prompt:RELEASE.2025-01-17T21-55-43Z
warp:
  repository: aistor
  image: warp:v1.4.0
{{- end -}}
