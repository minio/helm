#!/bin/bash

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$ROOT_DIR/scripts/release-lib.sh"

sed_inplace() {
	if [[ "$OSTYPE" == "darwin"* ]]; then
		sed -i "" "$@"
	else
		sed -i "$@"
	fi
}

# Full registry path of the "aistor" repository in values.yaml, which hosts
# every image of this chart.
REPO_PATH="quay.io/minio/aistor/"
REPO_PATH_RE=$(printf '%s' "$REPO_PATH" | sed 's/[.[\*^$]/\\&/g')

## Get latest releases from github repositories

SIDEKICK_OPERATOR_RELEASE=$(get_latest_release_with_suffix miniohq/aistor-operator ".sidekick-operator")
SIDEKICK_SIDECAR_RELEASE=$(get_latest_release_with_suffix miniohq/aistor-operator ".sidekick-sidecar")
# The injected load balancer is the AIStor Sidekick image, released
# independently of this operator.
SIDEKICK_RELEASE=$(get_latest_release miniohq/sidekick)

require_version "Sidekick operator" "$SIDEKICK_OPERATOR_RELEASE"
require_version "Sidekick sidecar" "$SIDEKICK_SIDECAR_RELEASE"
require_version "Sidekick" "$SIDEKICK_RELEASE"

OPERATOR_VERSION=$(echo "$SIDEKICK_OPERATOR_RELEASE" | sed -E 's/RELEASE.([0-9][0-9][0-9][0-9])-([0-9]+)-([0-9][0-9])T([0-9][0-9])-([0-9][0-9])-([0-9][0-9])Z/v\1\2\3\4\5\6.0.0/g')

cat Chart.yaml |
	sed "s/^appVersion: .*/appVersion: $OPERATOR_VERSION/" \
		>Chart.yaml.new
mv -f Chart.yaml.new Chart.yaml

# Each module is "key image:tag".
modules=(
	"sidekick-operator sidekick-operator:$SIDEKICK_OPERATOR_RELEASE"
	"sidekick sidekick:$SIDEKICK_RELEASE"
	"sidekick-sidecar sidekick-sidecar:$SIDEKICK_SIDECAR_RELEASE"
)

echo "Sidekick operator version: $SIDEKICK_OPERATOR_RELEASE"
echo "Sidekick version: $SIDEKICK_RELEASE"
echo ""
echo "Updating references to images"
for module in "${modules[@]}"; do
	name=$(echo $module | cut -d' ' -f1)
	image=$(echo $module | cut -d' ' -f2)
	echo "$name: $image"
done

AUTOGEN_FILE=values.yaml
AUTOGEN_TMP="$AUTOGEN_FILE-tmp"
AUTOGEN_LINE=$(grep -n '^# AUTOGENERATE$' $AUTOGEN_FILE | cut -d ':' -f 1)

head -n $AUTOGEN_LINE <$AUTOGEN_FILE >$AUTOGEN_TMP
(
	echo "images:"
	for module in "${modules[@]}"; do
		name=$(echo $module | cut -d' ' -f1)
		image=$(echo $module | cut -d' ' -f2)
		echo "  $name:"
		echo "    repository: aistor"
		echo "    image: $image"
	done
) >>$AUTOGEN_TMP

for test in tests/*-output.yaml; do
	for module in "${modules[@]}"; do
		image=$(echo "$module" | cut -d' ' -f2)
		image_name=${image%%:*}
		image_tag=${image#*:}
		# Park an optional ".fips" suffix (used by FIPS test fixtures) behind a
		# marker so updating the release tag does not strip it, then restore it.
		sed_inplace -E "s|(${REPO_PATH_RE}${image_name}:[^\"]*)\.fips\"|\1\"@@FIPS@@|g" "$test"
		sed_inplace "s|${REPO_PATH_RE}${image_name}:[^\"]*|${REPO_PATH}${image_name}:${image_tag}|g" "$test"
		sed_inplace "s|\"@@FIPS@@|.fips\"|g" "$test"
	done
done

mv -f $AUTOGEN_TMP $AUTOGEN_FILE

# No release script in this repository bumps the Sidekick image, so keep the
# Kustomize manifest (which `make check-helm` diffs against the chart) and the
# integration test pin in sync with values.yaml here.
for file in \
	"$ROOT_DIR/resources/sidekick/kubernetes/install/configmap.yaml" \
	"$ROOT_DIR/integrationtests/aistor/sidekick.go"; do
	sed_inplace "s|${REPO_PATH_RE}sidekick:[^\"]*|${REPO_PATH}sidekick:${SIDEKICK_RELEASE}|g" "$file"
done
