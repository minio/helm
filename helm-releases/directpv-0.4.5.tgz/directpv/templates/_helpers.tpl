{{/*
    directpv.isOpenShift returns whether the current cluster is OpenShift.
*/}}
{{- define "directpv.isOpenShift" -}}
{{- if ($.Values.forceOpenShift | default (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints")) -}}
{{- true -}}
{{- end -}}
{{- end -}}

{{/*
    directpv.isLegacy returns whether legacy volumes found.
    If Values.forceLegacyFlag is set, then it will use that value.
    If it is not set the template probes it from running cluster by
      - If any volume has 'directpv.min.io/migrated: true' label in directpvvolumes CRD or
        If at least one volume in directcsivolumes CRD

    PS: Note that auto-detect only works when Helm actually is able to
        read the resources from the cluster. It won't work during a dry-run
        or when using the `helm template` command.
*/}}
{{- define "directpv.isLegacy" -}}
{{- if hasKey .Values "forceLegacyFlag" -}}
  {{- $.Values.forceLegacyFlag -}}
{{- else -}}
  {{- $hasLegacyVolumes := false -}}
  {{- if (lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" "directcsivolumes.direct.csi.min.io") -}}
    {{- $legacyVolumes := lookup "direct.csi.min.io/v1beta5" "DirectCSIVolume" "" "" -}}
    {{- $hasLegacyVolumes = and $legacyVolumes (gt (len $legacyVolumes.items) 0) -}}
  {{- end -}}
  {{- $hasMigratedVolumes := false -}}
  {{- if (lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" "directpvvolumes.directpv.min.io") -}}
    {{- $volumes := lookup "directpv.min.io/v1beta1" "DirectPVVolume" "" "" -}}
    {{- if and $volumes (hasKey $volumes "items") -}}
      {{- range $volume := $volumes.items -}}
        {{- $labels := $volume.metadata.labels -}}
        {{- if and $labels (eq (get $labels "directpv.min.io/migrated") "true") -}}
          {{- $hasMigratedVolumes = true -}}
          {{- break -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
  {{- or $hasLegacyVolumes $hasMigratedVolumes -}}
{{- end -}}
{{- end -}}

{{/*
    directpv.defaultImages defines the default images used by DirectPV.
*/}}
{{- define "directpv.defaultImages" -}}
{{- if ($.Values.forceOpenShift | default (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints")) -}}
{{/* images when running on OpenShift */}}
directpv: quay.io/minio/directpv@sha256:dfce1cb76d6d4d0e3e74eb78b151727223b0651f143863cc8a73663b23bc02fb
livenessprobe: registry.redhat.io/openshift4/ose-csi-livenessprobe-rhel8@sha256:7fbc65be0a6042e02a7d5de622a2941fc13f91edb2657e1884a6aa39c2af37fb
csiNodeDriverRegistrar: registry.redhat.io/openshift4/ose-csi-node-driver-registrar-rhel8@sha256:d4c4fa9f857e73ae1aa49b9d6465a594e6a0c5fd72ef405c695f9e574ee290d8
csiProvisioner: registry.redhat.io/openshift4/ose-csi-external-provisioner-rhel8@sha256:67c72fd618ad457b58bcef5ed9c08d2418c1d38c3616509f0a310011cf378f27
csiResizer: registry.redhat.io/openshift4/ose-csi-external-resizer-rhel8@sha256:e69858ab415a56d1371c77cf2c55fcd3b62f41bc79b5f45a43746256611180a7
{{- else -}}
{{/* images when running on vanilla Kubernetes */}}
directpv: quay.io/minio/directpv:v5.1.3
livenessprobe: quay.io/minio/livenessprobe:v2.19.0-0
csiNodeDriverRegistrar: quay.io/minio/csi-node-driver-registrar:v2.17.0-0
csiProvisioner: quay.io/minio/csi-provisioner:v6.3.0-0
csiResizer: quay.io/minio/csi-resizer:v2.2.1-0
{{- end -}}
{{- end -}}

{{/*
    directpv.resolveImage returns the proper image for the given name.
*/}}
{{- define "directpv.resolveImage" -}}
{{- $emptyObj := ("{}" | fromJson) -}}
{{- $defaultImages := (include "directpv.defaultImages" .root | fromYaml) -}}
{{- $defaultImage := index $defaultImages .name -}}
{{- $images := .root.Values.images | default $emptyObj -}}
{{- $image := index $images .name -}}
{{- $image | default $defaultImage | default $defaultImages -}}
{{- end -}}

{{/*
    directpv.kubeletDirPath defines the default kubelet directory path.
*/}}
{{- define "directpv.kubeletDirPath" -}}
{{- clean (trimSuffix "/" (default "/var/lib/kubelet" .Values.kubeletDirPath)) -}}
{{- end -}}
