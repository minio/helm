#!/bin/bash

set -e

sed_inplace() {
	if [[ "$OSTYPE" == "darwin"* ]]; then
		sed -i "" "$@"
	else
		sed -i "$@"
	fi
}

get_latest_release_with_suffix() {
	suffix=$2
	gh release list --repo "$1" --json tagName,isPrerelease |
		jq -r --arg suf "$suffix" '
		[.[]
		| select(.isPrerelease == false)
		| select(.tagName | endswith("Z"+$suf))
		][0].tagName
		| sub($suf + "$"; "")'
}

get_latest_version() {
	gh release list --repo "$1" --json tagName,isPrerelease |
		jq -r '
		[.[]
		| select(.isPrerelease == false)
		| select(.tagName | startswith("v"))
		][0].tagName'
}

# Full registry path for a repository name, matching the repositories block in
# values.yaml.
repo_path() {
	case "$1" in
	sidekick) echo "quay.io/minio/" ;;
	*) echo "quay.io/minio/aistor/" ;;
	esac
}

## Get latest releases from github repositories

SIDEKICK_OPERATOR_RELEASE=$(get_latest_release_with_suffix miniohq/aistor-operator ".sidekick-operator")
SIDEKICK_SIDECAR_RELEASE=$(get_latest_release_with_suffix miniohq/aistor-operator ".sidekick-sidecar")
# The injected load balancer is the upstream MinIO Sidekick image, released
# independently of this operator.
SIDEKICK_RELEASE=$(get_latest_version minio/sidekick)

OPERATOR_VERSION=$(echo "$SIDEKICK_OPERATOR_RELEASE" | sed -E 's/RELEASE.([0-9][0-9][0-9][0-9])-([0-9]+)-([0-9][0-9])T([0-9][0-9])-([0-9][0-9])-([0-9][0-9])Z/v\1\2\3\4\5\6.0.0/g')

cat Chart.yaml |
	sed "s/^appVersion: .*/appVersion: $OPERATOR_VERSION/" \
		>Chart.yaml.new
mv -f Chart.yaml.new Chart.yaml

# Each module is "key repository image:tag".
modules=(
	"sidekick-operator aistor sidekick-operator:$SIDEKICK_OPERATOR_RELEASE"
	"sidekick sidekick sidekick:$SIDEKICK_RELEASE"
	"sidekick-sidecar aistor sidekick-sidecar:$SIDEKICK_SIDECAR_RELEASE"
)

echo "Sidekick operator version: $SIDEKICK_OPERATOR_RELEASE"
echo "Sidekick (upstream) version: $SIDEKICK_RELEASE"
echo ""
echo "Updating references to images"
for module in "${modules[@]}"; do
	name=$(echo $module | cut -d' ' -f1)
	image=$(echo $module | cut -d' ' -f3)
	echo "$name: $image"
done

AUTOGEN_FILE=values.yaml
AUTOGEN_TMP="$AUTOGEN_FILE-tmp"
AUTOGEN_LINE=$(grep -n '^# AUTOGENERATE$' $AUTOGEN_FILE | cut -d ':' -f 1)

head -n $AUTOGEN_LINE <$AUTOGEN_FILE >$AUTOGEN_TMP
(
	echo "images:"
	for module in "${modules[@]}"; do
		name=$(echo $module | cut -d' ' -f1)
		repository=$(echo $module | cut -d' ' -f2)
		image=$(echo $module | cut -d' ' -f3)
		echo "  $name:"
		echo "    repository: $repository"
		echo "    image: $image"
	done
) >>$AUTOGEN_TMP

for test in tests/*-output.yaml; do
	for module in "${modules[@]}"; do
		repository=$(echo "$module" | cut -d' ' -f2)
		image=$(echo "$module" | cut -d' ' -f3)
		image_name=${image%%:*}
		image_tag=${image#*:}
		path=$(repo_path "$repository")
		path_re=$(printf '%s' "$path" | sed 's/[.[\*^$]/\\&/g')
		sed_inplace "s|${path_re}${image_name}:[^\"]*|${path}${image_name}:${image_tag}|g" "$test"
	done
done

mv -f $AUTOGEN_TMP $AUTOGEN_FILE
