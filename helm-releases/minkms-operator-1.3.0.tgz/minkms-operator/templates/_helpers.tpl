{{/* 
    aistor.namespace returns the namespace for AIStor resources.
*/}}
{{- define "aistor.namespace" -}}
{{ $.Values.namespaceOverride | default $.Release.Namespace| trunc 63 | trimSuffix "-" | quote }}
{{- end -}}

{{/* 
    aistor.resolveImage resolves the given name into a fully qualified image name.
    - name: the name of the image in $.images
    - root: the root object
    - val: the value of the image in the current object
*/}}
{{- define "aistor.resolveImage" -}}

{{- $emptyObj := ("{}" | fromJson) -}}

{{- $defaultImages := (include "aistor.defaultImages" . | fromYaml) -}}
{{- $defaultImageDef := index $defaultImages .name -}}

{{- $images := .root.images | default $emptyObj -}}
{{- $imageDef := index $images .name -}}

{{- $repositoryName := $imageDef.repository | default $defaultImageDef.repository | default "" -}}

{{- $defaultRepositories := (include "aistor.defaultRepositories" . | fromYaml) -}}
{{- $defaultRepoDef := index $defaultRepositories $repositoryName -}}
{{- $defaultRepo := $defaultRepoDef | default "" -}}

{{- $repoDef := index .root.repositories $repositoryName -}}
{{- $repo := $repoDef | default $defaultRepo | default $emptyObj -}}

{{- $image := $imageDef.image | default $defaultImageDef.image | default "" -}}
{{- $defaultImage := printf "%s%s" ($repo.pathPrefix | default "") $image -}}
{{- if $repo.hostname -}}
{{- $defaultImage = printf "%s/%s%s" $repo.hostname ($repo.pathPrefix | default "") $image -}}
{{- end -}}

{{- .val.image | default $defaultImage -}}
{{- end -}}

{{/* 
    aistor.resolveImagePullPolicy resolves the given name into a pull policy.
    - name: the name of the image in $.images
    - root: the root object
    - val: the value of the pull policy in the current object
*/}}
{{- define "aistor.resolveImagePullPolicy" -}}

{{- $emptyObj := ("{}" | fromJson) -}}

{{- $defaultImages := (include "aistor.defaultImages" . | fromYaml) -}}
{{- $defaultImageDef := index $defaultImages .name -}}

{{- $images := .root.images | default $emptyObj -}}
{{- $imageDef := index $images .name -}}

{{- $repositoryName := $imageDef.repository | default $defaultImageDef.repository | default "" -}}

{{- $defaultRepositories := (include "aistor.defaultRepositories" . | fromYaml) -}}
{{- $defaultRepoDef := index $defaultRepositories $repositoryName -}}
{{- $defaultRepo := $defaultRepoDef | default "" -}}

{{- $repoDef := index .root.repositories $repositoryName -}}
{{- $repo := $repoDef | default $defaultRepo | default $emptyObj -}}

{{- .val.imagePullPolicy | default $repo.imagePullPolicy | default "" -}}
{{- end -}}

{{/* 
    aistor.resolveImagePullSecrets resolves the given name into a pull secrets.
    - name: the name of the image in $.images
    - root: the root object
*/}}
{{- define "aistor.resolveImagePullSecrets" -}}

{{- $emptyObj := ("{}" | fromJson) -}}
{{- $emptyArray := ("[]" | fromJsonArray) -}}

{{- $defaultImages := (include "aistor.defaultImages" . | fromYaml) -}}
{{- $defaultImageDef := index $defaultImages .name -}}

{{- $images := .root.images | default $emptyObj -}}
{{- $imageDef := index $images .name -}}

{{- $repositoryName := $imageDef.repository | default $defaultImageDef.repository | default "" -}}

{{- $defaultRepositories := (include "aistor.defaultRepositories" . | fromYaml) -}}
{{- $defaultRepoDef := index $defaultRepositories $repositoryName -}}
{{- $defaultRepo := $defaultRepoDef | default "" -}}

{{- $repoDef := index .root.repositories $repositoryName -}}
{{- $repo := $repoDef | default $defaultRepo | default $emptyObj -}}

{{- $repo.imagePullSecrets | default $emptyArray | toJson -}}
{{- end -}}

{{/* 
    aistor.resolveEnv resolves the given name into the environment.
    - name: the name of the image in $.images
    - root: the root object
*/}}
{{- define "aistor.resolveEnv" -}}

{{- $emptyObj := ("{}" | fromJson) -}}
{{- $emptyArray := ("[]" | fromJsonArray) -}}

{{- $defaultImages := (include "aistor.defaultImages" . | fromYaml) -}}
{{- $defaultImageDef := index $defaultImages .name -}}

{{- $images := .root.images | default $emptyObj -}}
{{- $imageDef := index $images .name -}}

{{- $imageDef.env | default $defaultImageDef.env | default $emptyArray | toJson -}}

{{- end -}}

{{/*
    aistor.isOpenShift returns whether the current cluster is OpenShift.
*/}}
{{- define "aistor.isOpenShift" -}}
{{- if ($.Values.global.forceOpenShift | default (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints")) -}}
{{- true -}}
{{- end -}}
{{- end -}}

{{/*
    aistor.operatorEnabled returns whether the operator is enabled.
*/}}
{{- define "aistor.operatorEnabled" -}}
{{- $emptyObj := "{}" | fromJson -}}
{{- $operators := .root.operators | default $emptyObj -}}
{{- $opValue := index $operators .operator | default $emptyObj }}
{{- if not $opValue.disabled }}
{{- true -}}
{{- end -}}
{{- end -}}

{{/*
    aistor.defaultRepositories returns the default repositories
*/}}
{{- define "aistor.defaultRepositories" -}}
aistor:
  hostname: quay.io
  pathPrefix: minio/aistor/
{{- end -}}

{{/*
    aistor.operators returns the default information for all operators
*/}}
{{- define "aistor.operators" -}}
minkms:
  images: ["minkms","minkms-sidecar"]
{{- end -}}

{{/* IMPORTANT: EVERYTHING BELOW THIS LINE WILL IS AUTOGENERATED */}}
{{/* AUTOGENERATE */}}

{{/*
    aistor.defaultImages returns the default list of images.
*/}}
{{- define "aistor.defaultImages" -}}
minkms:
  repository: aistor
  image: minkms:RELEASE.2025-11-12T19-14-51Z
minkms-sidecar:
  repository: aistor
  image: minkms-sidecar:RELEASE.2026-02-08T21-05-50Z
operator:
  repository: aistor
  image: operator:RELEASE.2026-02-09T03-12-43Z
{{- end -}}
