{{/*
    directpv.isOpenShift returns whether the current cluster is OpenShift.
*/}}
{{- define "directpv.isOpenShift" -}}
{{- if ($.Values.forceOpenShift | default (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints")) -}}
{{- true -}}
{{- end -}}
{{- end -}}

{{/*
    directpv.isLegacy returns whether legacy volumes found.
    If Values.forceLegacyFlag is set, then it will use that value.
    If it is not set the template probes it from running cluster by
      - If any volume has 'directpv.min.io/migrated: true' label in directpvvolumes CRD or
        If at least one volume in directcsivolumes CRD

    PS: Note that auto-detect only works when Helm actually is able to
        read the resources from the cluster. It won't work during a dry-run
        or when using the `helm template` command.
*/}}
{{- define "directpv.isLegacy" -}}
{{- if hasKey .Values "forceLegacyFlag" -}}
  {{- $.Values.forceLegacyFlag -}}
{{- else -}}
  {{- $hasLegacyVolumes := false -}}
  {{- if (lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" "directcsivolumes.direct.csi.min.io") -}}
    {{- $legacyVolumes := lookup "direct.csi.min.io/v1beta5" "DirectCSIVolume" "" "" -}}
    {{- $hasLegacyVolumes = and $legacyVolumes (gt (len $legacyVolumes.items) 0) -}}
  {{- end -}}
  {{- $hasMigratedVolumes := false -}}
  {{- if (lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" "directpvvolumes.directpv.min.io") -}}
    {{- $volumes := lookup "directpv.min.io/v1beta1" "DirectPVVolume" "" "" -}}
    {{- if and $volumes (hasKey $volumes "items") -}}
      {{- range $volume := $volumes.items -}}
        {{- $labels := $volume.metadata.labels -}}
        {{- if and $labels (eq (get $labels "directpv.min.io/migrated") "true") -}}
          {{- $hasMigratedVolumes = true -}}
          {{- break -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
  {{- or $hasLegacyVolumes $hasMigratedVolumes -}}
{{- end -}}
{{- end -}}

{{/*
    directpv.defaultImages defines the default images used by DirectPV.
*/}}
{{- define "directpv.defaultImages" -}}
{{- if ($.Values.forceOpenShift | default (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints")) -}}
{{/* images when running on OpenShift */}}
directpv: quay.io/minio/directpv@sha256:1add60387c6714470907ef109711042947959de6bc80ddd02107e76fa79abaa2
livenessprobe: registry.redhat.io/openshift4/ose-csi-livenessprobe-rhel8@sha256:a516448355b6c360953151ed14c1b9eaf977a674a9ff65216d3076ddc9355987
csiNodeDriverRegistrar: registry.redhat.io/openshift4/ose-csi-node-driver-registrar-rhel8@sha256:b61fcc8774f2dde2ed46df52630b495ff8f5bb53a80a4733006b0197297b0264
csiProvisioner: registry.redhat.io/openshift4/ose-csi-external-provisioner-rhel8@sha256:ecf86bed1b174e57b9b52ebf5c2792da25d7ab2daccef15bdac98a47aa09ff3e
csiResizer: registry.redhat.io/openshift4/ose-csi-external-resizer-rhel8@sha256:370f6a90b4792ac9275b355f17b457c8348d3230fd2d272c8a447513ba3473b8
{{- else -}}
{{/* images when running on vanilla Kubernetes */}}
directpv: quay.io/minio/directpv:v5.1.2
livenessprobe: quay.io/minio/livenessprobe:v2.18.0-0
csiNodeDriverRegistrar: quay.io/minio/csi-node-driver-registrar:v2.16.0-0
csiProvisioner: quay.io/minio/csi-provisioner:v6.2.0-0
csiResizer: quay.io/minio/csi-resizer:v2.1.0-0
{{- end -}}
{{- end -}}

{{/*
    directpv.resolveImage returns the proper image for the given name.
*/}}
{{- define "directpv.resolveImage" -}}
{{- $emptyObj := ("{}" | fromJson) -}}
{{- $defaultImages := (include "directpv.defaultImages" .root | fromYaml) -}}
{{- $defaultImage := index $defaultImages .name -}}
{{- $images := .root.Values.images | default $emptyObj -}}
{{- $image := index $images .name -}}
{{- $image | default $defaultImage | default $defaultImages -}}
{{- end -}}

{{/*
    directpv.kubeletDirPath defines the default kubelet directory path.
*/}}
{{- define "directpv.kubeletDirPath" -}}
{{- clean (trimSuffix "/" (default "/var/lib/kubelet" .Values.kubeletDirPath)) -}}
{{- end -}}
